/*
 * Copyright � 2008 Nokia Corporation.
 */

#ifndef AUDIOSTREAMDOCUMENT_H
#define AUDIOSTREAMDOCUMENT_H

// INCLUDES
#include <akndoc.h>
   
// CONSTANTS

// FORWARD DECLARATIONS
class  CEikAppUi;

// CLASS DECLARATION

/**
*  CAudioStreamDocument application document class.
*  
*/
class CAudioStreamDocument : public CAknDocument
    {
    public: // Constructors and destructor
        /**
        * Two-phased constructor.
        */
        static CAudioStreamDocument* NewL(CEikApplication& aApp);

        /**
        * Destructor.
        */
        virtual ~CAudioStreamDocument();

    public: // New functions

    public: // Functions from base classes
        
    protected:  // New functions

    protected:  // Functions from base classes

    private:

        /**
        * EPOC default constructor.
        */
        CAudioStreamDocument(CEikApplication& aApp);
        void ConstructL();

    private:

        /**
        * From CEikDocument, create CAudioStreamAppUi "App UI" object.
        */
        CEikAppUi* CreateAppUiL();
    };

#endif

// End of File

