/*
 * Copyright � 2008 Nokia Corporation.
 */

// INCLUDE FILES
#include    "DescriptorExApp.h"
#include    "DescriptorExDocument.h"

#include <eikstart.h>


// -----------------------------------------------------------------------------
// Returns application UID
// -----------------------------------------------------------------------------
TUid CDescriptorExApp::AppDllUid() const
    {
    return KUidDescriptorEx;
    }

// -----------------------------------------------------------------------------
// Creates CDescriptorExDocument object
// -----------------------------------------------------------------------------
CApaDocument* CDescriptorExApp::CreateDocumentL()
    {
    return CDescriptorExDocument::NewL( *this );
    }

// -----------------------------------------------------------------------------
// Constructs CDescriptorExApp
// Returns: created application object
// -----------------------------------------------------------------------------
EXPORT_C CApaApplication* NewApplication()
    {
    return new CDescriptorExApp;
    }

GLDEF_C TInt E32Main()
    {
    return EikStart::RunApplication( NewApplication );
    }


