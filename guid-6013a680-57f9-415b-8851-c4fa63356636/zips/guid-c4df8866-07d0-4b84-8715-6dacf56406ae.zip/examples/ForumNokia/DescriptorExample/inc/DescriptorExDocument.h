/*
 * Copyright � 2008 Nokia Corporation.
 */

#ifndef DESCRIPTOREXDOCUMENT_H
#define DESCRIPTOREXDOCUMENT_H

#include <akndoc.h>
class  CEikAppUi;

class CDescriptorExDocument : public CAknDocument
    {
    public:
        static CDescriptorExDocument* NewL(CEikApplication& aApp);
        virtual ~CDescriptorExDocument();
        CDescriptorExDocument(CEikApplication& aApp);
        void ConstructL();
    private:
        CEikAppUi* CreateAppUiL();
    };
#endif
