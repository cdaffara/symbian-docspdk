/*
 * Copyright � 2008 Nokia Corporation.
 */

#ifndef DESCRIPTOREXAPP_H
#define DESCRIPTOREXAPP_H

#include <aknapp.h>

// Uid for the application, this should match the one in the mmp file
const TUid KUidDescriptorEx = {0xE01FF1C7};

class CDescriptorExApp : public CAknApplication
    {
    private:
        /**
        * Creates an empty document capable of creating a
        * of CDescriptorExAppUi instance when requested.
        */
        CApaDocument* CreateDocumentL();
        TUid AppDllUid() const;
    };

#endif
