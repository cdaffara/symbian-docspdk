// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// Contains the header files and literal constants required to run the example.
//



/**
 @file
*/
#ifndef __SGLLIST_H__
#define __SGLLIST_H__

#include <e32base.h>
#include <e32std.h>
#include <e32cons.h>

_LIT(KTextPressAnyKey, "[press any key]\r\n");
_LIT(KTextNewLine, "\n");
_LIT(KTxtEPOC32EX, "EXAMPLES");
_LIT(KTxtExampleCode, "Symbian platform Singly Linked List Example Code");
_LIT(KTxtOK, "ok");
_LIT(KFormatFailed, "failed: leave code=%d");

#endif

