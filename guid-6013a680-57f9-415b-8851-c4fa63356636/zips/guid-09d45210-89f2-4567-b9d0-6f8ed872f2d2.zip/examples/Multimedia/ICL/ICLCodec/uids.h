// Uids.h
//
// // Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//
//


#ifndef __PNGUIDS_H__
#define __PNGUIDS_H__

// DLL and implementation UIDs
#define KExPNGCodecDllUidValue				0xE8000063
#define KExPNGDecoderImplementationUidValue	0x101F4123
#define KExPNGEncoderImplementationUidValue	0x101F4124

#endif
