/*
 * Copyright � 2008 Nokia Corporation.
 */

#ifndef TZLOCALIZERAPP_H
#define TZLOCALIZERAPP_H

// INCLUDES
#include <aknapp.h>

// CONSTANTS
// UID of the application
const TUid KUidTZLocalizer = { 0xE4279460 };

// CLASS DECLARATION

//
//CTZLocalizerApp application class.
//Provides factory to create concrete document object.
//
//
class CTZLocalizerApp : public CAknApplication
    {
    
    public: // Functions from base classes
    private:

        //
        //From CApaApplication, creates CTZLocalizerDocument document object.
        //@return A pointer to the created document object.
        //
        CApaDocument* CreateDocumentL();
        
        //
        //From CApaApplication, returns application's UID (KUidTZLocalizer).
        //@return The value of KUidTZLocalizer.
        //
        TUid AppDllUid() const;
    };

#endif

// End of File

