/*
 * Copyright � 2008 Nokia Corporation.
 */

#ifndef TZLOCALIZERDIALOG_H
#define TZLOCALIZERDIALOG_H

// INCLUDES
#include <eikdialg.h>
#include <aknlists.h> 

// FORWARD DECLARATIONS

// CLASS DECLARATION

//
//CTZLocalizerDialog dialog class
//
//
class CTZLocalizerDialog : public CEikDialog
    {

    public: // Constructors and destructor
        //
        //Destructor.
        //
        ~CTZLocalizerDialog();

    public: // New functions
        void SetListBoxTextL( CDesC16ArrayFlat* aArray );

    protected:  // Functions from base classes
        void PreLayoutDynInitL();
        TBool OkToExitL( TInt aButtonId );
        void SetSizeAndPosition(const TSize& aSize);
        
    private: //data

    };

#endif

// End of File
