/*
 * Copyright � 2008 Nokia Corporation.
 */

#ifndef TZLOCALIZERDOCUMENT_H
#define TZLOCALIZERDOCUMENT_H

// INCLUDES
#include <akndoc.h>
   
// CONSTANTS

// FORWARD DECLARATIONS
class  CEikAppUi;

// CLASS DECLARATION

class CTZLocalizerDocument : public CAknDocument
    {
    public: // Constructors and destructor
        static CTZLocalizerDocument* NewL(CEikApplication& aApp);

        virtual ~CTZLocalizerDocument();

    private:

        CTZLocalizerDocument(CEikApplication& aApp);
        void ConstructL();

    private:
        CEikAppUi* CreateAppUiL();
    };

#endif

// End of File

