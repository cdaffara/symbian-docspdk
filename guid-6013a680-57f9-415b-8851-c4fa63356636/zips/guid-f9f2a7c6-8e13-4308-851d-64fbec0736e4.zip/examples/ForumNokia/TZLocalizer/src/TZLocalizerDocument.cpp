/*
 * Copyright � 2008 Nokia Corporation.
 */

// INCLUDE FILES
#include <t32wld.h>
#include "TZLocalizerDocument.h"
#include "TZLocalizerAppUi.h"

// ================= MEMBER FUNCTIONS =======================

// constructor
CTZLocalizerDocument::CTZLocalizerDocument(CEikApplication& aApp)
: CAknDocument(aApp)    
    {
    }

// destructor
CTZLocalizerDocument::~CTZLocalizerDocument()
    {
    }

// EPOC default constructor can leave.
void CTZLocalizerDocument::ConstructL()
    {
    }

// Two-phased constructor.
CTZLocalizerDocument* CTZLocalizerDocument::NewL(
        CEikApplication& aApp)     // CTZLocalizerApp reference
    {
    CTZLocalizerDocument* self = new (ELeave) CTZLocalizerDocument( aApp );
    CleanupStack::PushL( self );
    self->ConstructL();
    CleanupStack::Pop(self);

    return self;
    }
    
// ----------------------------------------------------
// CTZLocalizerDocument::CreateAppUiL()
// constructs CTZLocalizerAppUi
// ----------------------------------------------------
//
CEikAppUi* CTZLocalizerDocument::CreateAppUiL()
    {
    return new (ELeave) CTZLocalizerAppUi;
    }

// End of File  
