// helloworlddllexample.cpp
// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

// This example is a simple PIPS STDDLL application that contains the export function definition.
#include "helloworlddllexample.h"
#include <stdio.h>

/*
Definition of the export function declared in the header file.
This function prints a welcome message.
*/
void PrintHelloWorld()
	{
	char str[90]=" Welcome to HelloWorld Basic EXE and DLL example, using symbolic name lookup\n";
	printf("%s",str);
	getchar();
	}
