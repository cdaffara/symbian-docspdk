/*
 * Copyright � 2008 Nokia Corporation.
 */

#ifndef INTERNETEMAILDOCUMENT_H
#define INTERNETEMAILDOCUMENT_H

// INCLUDES
#include <akndoc.h>
   
// CONSTANTS

// FORWARD DECLARATIONS
class  CEikAppUi;

// CLASS DECLARATION

/**
*  CInternetEmailDocument application class.
*/
class CInternetEmailDocument : public CAknDocument
    {
    public: // Constructors and destructor
        /**
        * Two-phased constructor.
        */
        static CInternetEmailDocument* NewL(CEikApplication& aApp);

        /**
        * Destructor.
        */
        virtual ~CInternetEmailDocument();

    public: // New functions

    public: // from CEikDocument
    CFileStore* OpenFileL(TBool aDoOpen,const TDesC& aFilename,RFs& aFs);
    protected:  // New functions

    protected:  // Functions from base classes

    private:

        /**
        * EPOC default constructor.
        */
        CInternetEmailDocument(CEikApplication& aApp);
        void ConstructL();

    private:

        /**
        * From CEikDocument, create CInternetEmailAppUi "App UI" object.
        */
        CEikAppUi* CreateAppUiL();  

    private:
    };

#endif

// End of File

