// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// A program which uses dynamically linked DLLs.
//

	// standard example header
#include <e32cons.h>

#ifndef __UsingDLLs_H
#define __UsingDLLs_H

	// The UID for Messenger DLLs.
	// The client imposes this on DLLs which are required
	// to satisfy the protocol 

const TInt KMessengerUidValue=0x10004262;
const TUid KMessengerUid={KMessengerUidValue};

class CMessenger : public CBase
  	{
public:
	virtual void ConstructL(CConsoleBase* aConsole, const TDesC& aName)=0;
	virtual void ShowMessage()=0;
protected:
	CConsoleBase* iConsole;
	HBufC*        iName;
	};

#endif
