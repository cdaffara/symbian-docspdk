/*
 * Copyright (c) 2009 Nokia Corporation.
 */

#ifndef __CLIENT_APPUI_H__
#define __CLIENT_APPUI_H__

#include <aknappui.h>

#include <aknmessagequerydialog.h>

/*
* Forward declarations
*/
class CClientAppView;
class CClientEngine;

class CClientAppUi : public CAknAppUi
  {
public:
  /*
  * ConstructL()
  *
  * Perform the second phase construction of a CClientAppUi object.
  *
  * Params:
  *   -
  *
  * Returns:
  *     -
  *
  */
  void ConstructL();

  /*
  * CClientAppUi()
  *
  * First phase construction of CClientAppUi.
  *
  * Params:
  *   -
  *
  * Returns:
  *     -
  *
  */
  CClientAppUi();

  /*
  * ~CClientAppUi()
  *
  * Destructor for CClientAppUi.
  *
  * Params:
  *   -
  *
  * Returns:
  *     -
  *
  */
  ~CClientAppUi();

/*
* from CAknAppUi
*/
public:
  /*
  * HandleCommandL()
  *
  * Handles user commands.
  *
  * Params:
  *   aCommand: Command ID.
  *
  * Returns:
  *     -
  *
  */
  void HandleCommandL(TInt aCommand);

  /*
  * DynInitMenuPaneL()
  *
  * Provides dynamic initialization of the menu pane.
  * Called by framework when menu pane is activated.
  *
  * Params:
  *   aMenuId: Resource ID identifying the menu pane to initialise.
  *   aMenuPane: The in-memory representation of the menu pane.
  *
  * Returns:
  *     -
  *
  */
  void DynInitMenuPaneL(TInt aMenuId, CEikMenuPane* aMenuPane);

private: // from CAknAppUi

  /*
  * HelpContextL()
  *
  * Return the help context for this application
  *
  * Returns:
  *     A pointer to the help context
  *
  */
  CArrayFix<TCoeHelpContext>* HelpContextL() const;

private:
  CClientAppView* iAppView;
  CClientEngine* iEngine;
  };

#endif // __CLIENT_APPUI_H__
