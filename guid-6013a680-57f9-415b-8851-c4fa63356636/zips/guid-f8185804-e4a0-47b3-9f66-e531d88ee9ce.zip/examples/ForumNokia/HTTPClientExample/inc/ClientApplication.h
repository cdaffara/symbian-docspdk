/*
 * Copyright (c) 2009 Nokia Corporation.
 */

#ifndef __CLIENT_APPLICATION_H__
#define __CLIENT_APPLICATION_H__

#include <aknapp.h>

// UID for the application; this should correspond to the uid defined in
// the mmp file
const TUid KUidClientApp = {0xA00002DC};
const TUid KUidHelpFile = {0x2000E190};  // From help rtf file


class CClientApplication : public CAknApplication
    {
/*
* From CAknApplication
*/
public:
  /*
  * AppDllUid()
  *
  * Returns the UID for the Client application
  *
  * Params:
  *   -
  *
  * Returns:
  *     UID of the application.
  *
  */
    TUid AppDllUid() const;

/*
* From CAknApplication
*/
protected:
  /*
  * CreateDocumentL()
  *
  * Creates new document and returns pointer to it. Called by the application
  * DLL framework to create a new instance of the document associated with this
  * application.
  *
  * Params:
  *   -
  *
  * Returns:
  *     -
  *
  */
    CApaDocument* CreateDocumentL();
    };

#endif // __CLIENT_APPLICATION_H__
