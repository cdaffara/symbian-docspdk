/*
 * Copyright (c) 2009 Nokia Corporation.
 */

#include "ClientDocument.h"
#include "ClientApplication.h"

// ----------------------------------------------------------------------------
// CClientApplication::CreateDocumentL()
//
// Creates an Client document, and returns a pointer to it
// ----------------------------------------------------------------------------
CApaDocument* CClientApplication::CreateDocumentL()
  {
  return (static_cast<CApaDocument*>(CClientDocument::NewL(*this)));
  }

// ----------------------------------------------------------------------------
// CClientApplication::AppDllUid()
//
// Returns the UID for the Client application
// ----------------------------------------------------------------------------
TUid CClientApplication::AppDllUid() const
  {
    return KUidClientApp;
  }

// end of file
