/*
 * Copyright (c) 2009 Nokia Corporation.
 */

#include <eikstart.h>
#include "ClientApplication.h"

// ----------------------------------------------------------------------------
// NewApplication()
//
// Create an application, and return a pointer to it
// ----------------------------------------------------------------------------
EXPORT_C CApaApplication* NewApplication()
  {
  return (static_cast<CApaApplication*>(new CClientApplication));
  }

// ---------------------------------------------------------
// E32Main()
// Entry point function for new (>= 9.0) EPOC Apps (exe)
// Returns: Sistem Wide error codes or KErrNone if all goes well
// ---------------------------------------------------------
//
GLDEF_C TInt E32Main()
{
  return EikStart::RunApplication( NewApplication );
}

// end of file
