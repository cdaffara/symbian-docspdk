// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// Contains the definition of the TLetter class.
//



/**
 @file
*/
#ifndef __LETTER_H__
#define __LETTER_H__

#include "dbllist.h"

/**
Represents a character in the string.
This string of characters is a doubly linked list of the
objects of the TLetter class.
@see CMyString::iString.
*/
class TLetter
	{
public:
	TLetter(TUint aChar);
public:
	/**
	The character value.
	*/
	TChar iChar;
	/**
	The link object of the doubly linked list.
	*/
	TDblQueLink iDLink;
	};

#endif

