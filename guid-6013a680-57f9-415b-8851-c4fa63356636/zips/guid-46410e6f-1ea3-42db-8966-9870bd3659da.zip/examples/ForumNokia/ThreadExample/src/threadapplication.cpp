/*
* ============================================================================
*  Name     : CThreadApplication from CThreadApplication.h
*  Part of  : Thread
*  Created  : 04.02.2005 by Forum Nokia
*  Version  : 1.0
*  Copyright: Nokia Corporation
* ============================================================================
*/

// INCLUDES
#include "ThreadDocument.h"
#include "ThreadApplication.h"

// UID for the application; this should correspond to the uid defined in the mmp file
const TUid KUidThreadApp = {0x101FF1CC};

CApaDocument* CThreadApplication::CreateDocumentL()
    {  
    // Create an Thread document, and return a pointer to it
    return (static_cast<CApaDocument*>(CThreadDocument::NewL(*this))); 
    }

TUid CThreadApplication::AppDllUid() const
    {
    // Return the UID for the Thread application
    return KUidThreadApp;
    }
