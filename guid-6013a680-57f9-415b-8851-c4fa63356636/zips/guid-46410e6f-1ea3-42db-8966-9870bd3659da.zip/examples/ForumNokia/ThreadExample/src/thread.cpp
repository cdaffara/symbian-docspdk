/*
* ============================================================================
*  Name     : Thread.Cpp
*  Part of  : Thread
*  Created  : 04.02.2005 by Forum Nokia
*  Version  : 1.0
*  Copyright: Nokia Corporation
* ============================================================================
*/

// INCLUDES

//#ifdef __SERIES60_30__
#include <eikstart.h>
//#endif

#include "ThreadApplication.h"

//#ifdef __SERIES60_30__

LOCAL_C CApaApplication* NewApplication()
    {
    return new CThreadApplication;
    }
    
GLDEF_C TInt E32Main()
    {
    return EikStart::RunApplication( NewApplication );
    }

/*
#else

// DLL entry point, return that everything is ok
GLDEF_C TInt E32Dll(TDllReason aReason)
    {
    return KErrNone;
    }

// Create an application, and return a pointer to it
EXPORT_C CApaApplication* NewApplication() 
    {
    return (static_cast<CApaApplication*>(new CThreadApplication));
    }
    
#endif
*/
