/*
* ============================================================================
*  Name     : CThreadApplication from CThreadApplication.h
*  Part of  : Thread
*  Created  : 04.02.2005 by Forum Nokia
*  Description:
*     Declares main application class.
*  Version  : 1.0
*  Copyright: Nokia Corporation
* ============================================================================
*/

#ifndef THREAD_APPLICATION_H
#define THREAD_APPLICATION_H

// INCLUDES
#include <aknapp.h>

/*! 
* CThreadApplication
*  
* discussion An instance of CThreadApplication is the application part of the AVKON
* application framework for the Thread example application.
 */
class CThreadApplication : public CAknApplication
    {
public:  // from CAknApplication

/*! 
* AppDllUid()
*  
* discussion Return the application DLL UID value
* result the UID of this Application/Dll.
*/
    TUid AppDllUid() const;

protected: // from CAknApplication

/*! 
* CreateDocumentL
*  
* discussion Create a CApaDocument object and return a pointer to it
* result a pointer to the created document.
*/
    CApaDocument* CreateDocumentL();
    };

#endif // THREAD_APPLICATION_H
