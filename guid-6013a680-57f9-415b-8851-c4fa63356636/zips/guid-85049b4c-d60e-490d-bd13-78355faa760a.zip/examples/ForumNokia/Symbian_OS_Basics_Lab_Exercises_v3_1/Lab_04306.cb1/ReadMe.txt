Lab 04306.cb1

There is no starter or solution code associated with this lab.
