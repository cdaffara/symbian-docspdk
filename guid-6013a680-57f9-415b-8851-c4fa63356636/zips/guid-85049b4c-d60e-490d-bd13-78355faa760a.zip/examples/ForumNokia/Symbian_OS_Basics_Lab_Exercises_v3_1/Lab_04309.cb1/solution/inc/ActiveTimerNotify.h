// Copyright (c) 2006 Nokia Corporation.

#ifndef _ACTIVE_TIMER_NOTIFY_H
#define _ACTIVE_TIMER_NOTIFY_H

class MActiveTimerNotify
    {
    public:
        virtual void TimerComplete(TInt aError) = 0;
    };

#endif // _ACTIVE_TIMER_NOTIFY_H

// End of file