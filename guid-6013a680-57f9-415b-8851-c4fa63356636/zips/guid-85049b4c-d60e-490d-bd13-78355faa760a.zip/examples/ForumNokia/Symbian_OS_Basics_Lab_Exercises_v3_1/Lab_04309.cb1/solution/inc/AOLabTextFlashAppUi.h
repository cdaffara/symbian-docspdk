// Copyright (c) 2006 Nokia Corporation.

#ifndef __AOLABTEXTFLASHAPPUI_h__
#define __AOLABTEXTFLASHAPPUI_h__

#include <aknappui.h>

class CAOLabTextFlashContainer;

// CAOLabTextFlashAppUi application UI class.
// Interacts with the user through the UI and request 
// message processing from the handler class
class CAOLabTextFlashAppUi : public CAknAppUi
    {
    public: // Constructors and destructor

        void ConstructL();
        CAOLabTextFlashAppUi();
        virtual ~CAOLabTextFlashAppUi();

    private:  // Functions from base classes

        // From CEikAppUi
        void HandleCommandL( TInt aCommand );

		// From MEikStatusPaneObserver
		void HandleStatusPaneSizeChange();
		
		void DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane);
        
    private: // Data

        CAOLabTextFlashContainer* iAppContainer; 
    };

#endif // __AOLABTEXTFLASHAPPUI_h__

// End of File
