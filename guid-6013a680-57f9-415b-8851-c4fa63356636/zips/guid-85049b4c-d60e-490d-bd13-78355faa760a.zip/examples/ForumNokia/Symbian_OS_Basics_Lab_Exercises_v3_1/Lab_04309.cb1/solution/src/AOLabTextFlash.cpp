// Copyright (c) 2006 Nokia Corporation.

#include <eikstart.h>
#include "AOLabTextFlashApplication.h"


// Called by the application framework to create the application object
LOCAL_C CApaApplication* NewApplication()
	{
	return new CAOLabTextFlashApplication;
	}


// Entry point function
GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication( NewApplication );
	}

// End of file