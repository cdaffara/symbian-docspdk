// Copyright (c) 2006 Nokia Corporation.

#ifndef __AOLABTEXTFLASHDOCUMENT_h__
#define __AOLABTEXTFLASHDOCUMENT_h__

#include <akndoc.h>

class CAOLabTextFlashAppUi;
class CEikApplication;

// CAOLabTextFlashDocument application class.
// An instance of class CAOLabTextFlashDocument is the Document part of the
// AVKON application framework for the AOLabTextFlash example application.
class CAOLabTextFlashDocument : public CAknDocument
    {
    public: // Constructors and destructor
    
        static CAOLabTextFlashDocument* NewL( CEikApplication& aApp );
        static CAOLabTextFlashDocument* NewLC( CEikApplication& aApp );
        virtual ~CAOLabTextFlashDocument();

    public: // Functions from base classes

        // From CEikDocument
        CEikAppUi* CreateAppUiL();

    private: // Constructors

        void ConstructL();
        CAOLabTextFlashDocument(CEikApplication& aApp);
    };

#endif // __AOLABTEXTFLASHDOCUMENT_h__

// End of File
