// Copyright (c) 2006 Nokia Corporation.

#include "AOLabTextFlashDocument.h"
#include "AOLabTextFlashApplication.h"

// UID for the application;
const TUid KUidAOLabTextFlashApp = { 0x0B49C4AE };


// Creates CApaDocument object
CApaDocument* CAOLabTextFlashApplication::CreateDocumentL()
    {
    return CAOLabTextFlashDocument::NewL(*this);
    }


// Returns the application UID
TUid CAOLabTextFlashApplication::AppDllUid() const
    {  
    return KUidAOLabTextFlashApp;
    }

// End of File
