// Copyright (c) 2006 Nokia Corporation.

#ifndef _ACTIVE_TIMER_H
#define _ACTIVE_TIMER_H

#include <e32base.h>

class CActiveTimer : public CActive
    {
    public: // construction / destruction
    
        static CActiveTimer* NewL();
        ~CActiveTimer();

    public: // new functions
    
        void After(TTimeIntervalMicroSeconds32 anInterval);

    protected: // CActive overrides
    
        void RunL();
        void DoCancel();

    protected: // construction

        CActiveTimer();
        void ConstructL();

    protected: // data
    };

#endif // _ACTIVE_TIMER_H

// End of file