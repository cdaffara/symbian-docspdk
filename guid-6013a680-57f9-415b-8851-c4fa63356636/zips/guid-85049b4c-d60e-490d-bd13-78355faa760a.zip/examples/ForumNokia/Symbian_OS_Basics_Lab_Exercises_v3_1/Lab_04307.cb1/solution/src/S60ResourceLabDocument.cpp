// Copyright (c) 2006 Nokia Corporation.

// INCLUDE FILES
#include "S60ResourceLabDocument.h"
#include "S60ResourceLabAppUi.h"

// ================= MEMBER FUNCTIONS =======================

// constructor
CS60ResourceLabDocument::CS60ResourceLabDocument(CEikApplication& aApp)
: CAknDocument(aApp)    
    {
    }

// destructor
CS60ResourceLabDocument::~CS60ResourceLabDocument()
    {
    }

// EPOC default constructor can leave.
void CS60ResourceLabDocument::ConstructL()
    {
    }

// Two-phased constructor.
CS60ResourceLabDocument* CS60ResourceLabDocument::NewL(
        CEikApplication& aApp)     // CS60ResourceLabApp reference
    {
    CS60ResourceLabDocument* self = new (ELeave) CS60ResourceLabDocument( aApp );
    CleanupStack::PushL( self );
    self->ConstructL();
    CleanupStack::Pop();

    return self;
    }
    
// ----------------------------------------------------
// CS60ResourceLabDocument::CreateAppUiL()
// constructs CS60ResourceLabAppUi
// ----------------------------------------------------
//
CEikAppUi* CS60ResourceLabDocument::CreateAppUiL()
    {
    return new (ELeave) CS60ResourceLabAppUi;
    }

// End of File  
