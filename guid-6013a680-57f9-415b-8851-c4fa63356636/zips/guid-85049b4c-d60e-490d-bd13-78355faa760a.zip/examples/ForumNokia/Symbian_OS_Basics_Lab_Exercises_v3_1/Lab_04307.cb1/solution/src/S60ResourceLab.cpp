// Copyright (c) 2006 Nokia Corporation.

// INCLUDE FILES
#include <eikstart.h>
#include "S60ResourceLabApplication.h"


LOCAL_C CApaApplication* NewApplication()
	{
	return new CS60ResourceLabApp;
	}

GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication( NewApplication );
	}

