// Copyright (c) 2006 Nokia Corporation.

#ifndef S60RESOURCELABDOCUMENT_H
#define S60RESOURCELABDOCUMENT_H

// INCLUDES
#include <akndoc.h>
   
// CONSTANTS

// FORWARD DECLARATIONS
class  CEikAppUi;

// CLASS DECLARATION

/**
*  CS60ResourceLabDocument application class.
*/
class CS60ResourceLabDocument : public CAknDocument
    {
    public: // Constructors and destructor
        /**
        * Two-phased constructor.
        */
        static CS60ResourceLabDocument* NewL(CEikApplication& aApp);

        /**
        * Destructor.
        */
        virtual ~CS60ResourceLabDocument();

    public: // New functions

    protected:  // New functions

    protected:  // Functions from base classes

    private:

        /**
        * EPOC default constructor.
        */
        CS60ResourceLabDocument(CEikApplication& aApp);
        void ConstructL();

    private:

        /**
        * From CEikDocument, create CS60ResourceLabAppUi "App UI" object.
        */
        CEikAppUi* CreateAppUiL();
    };

#endif

// End of File

