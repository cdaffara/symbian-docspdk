// Copyright: (c) 2006 Nokia Ltd.  All rights reserved.

#ifndef S60MEMORYLABCONTAINER_H
#define S60MEMORYLABCONTAINER_H

// INCLUDES
#include <coecntrl.h>
   
// FORWARD DECLARATIONS
class CEikLabel;        // for example labels

// CLASS DECLARATION

/**
*  CS60MemoryLabContainer  container control class.
*  
*/
class CS60MemoryLabContainer : public CCoeControl, MCoeControlObserver
    {
    public: // Constructors and destructor
        
        /**
        * EPOC default constructor.
        * @param aRect Frame rectangle for container.
        */
        void ConstructL(const TRect& aRect);

        /**
        * Destructor.
        */
        ~CS60MemoryLabContainer();

    public: // New functions
        void ToggleLabelsL();
        void CleanupStackTestL();

    public: // Functions from base classes

    private: // Functions from base classes

       /**
        * From CoeControl,SizeChanged.
        */
        void SizeChanged();

       /**
        * From CoeControl,CountComponentControls.
        */
        TInt CountComponentControls() const;

       /**
        * From CCoeControl,ComponentControl.
        */
        CCoeControl* ComponentControl(TInt aIndex) const;

       /**
        * From CCoeControl,Draw.
        */
        void Draw(const TRect& aRect) const;

	   /**
        * From ?base_class ?member_description
        */
        // event handling section
        // e.g Listbox events
        void HandleControlEventL(CCoeControl* aControl,TCoeEvent aEventType);
        
    private: //data
        
        CEikLabel* iTopLabel;          // example label
        CEikLabel* iBottomLabel;      // example label
        TBool      iToggleFlag;
    };

#endif

// End of File
