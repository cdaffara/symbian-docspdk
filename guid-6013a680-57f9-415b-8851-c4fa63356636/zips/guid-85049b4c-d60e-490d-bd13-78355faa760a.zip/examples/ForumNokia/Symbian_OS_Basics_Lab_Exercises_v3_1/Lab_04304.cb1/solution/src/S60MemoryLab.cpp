// Copyright: (c) 2006 Nokia Ltd.  All rights reserved.

// INCLUDE FILES
#include <eikstart.h>
#include "S60MemoryLabApplication.h"


LOCAL_C CApaApplication* NewApplication()
	{
	return new CS60MemoryLabApplication;
	}

GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication( NewApplication );
	}

