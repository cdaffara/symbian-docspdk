// Copyright (c) 2006 Nokia Corporation.

// INCLUDE FILES
#include "S60ClientServLabDocument.h"
#include "S60ClientServLabAppUi.h"

// ================= MEMBER FUNCTIONS =======================

// constructor
CS60ClientServLabDocument::CS60ClientServLabDocument(CEikApplication& aApp)
: CAknDocument(aApp)    
    {
    }

// destructor
CS60ClientServLabDocument::~CS60ClientServLabDocument()
    {
    }

// EPOC default constructor can leave.
void CS60ClientServLabDocument::ConstructL()
    {
    }

// Two-phased constructor.
CS60ClientServLabDocument* CS60ClientServLabDocument::NewL(
        CEikApplication& aApp)     // CS60ClientServLabApp reference
    {
    CS60ClientServLabDocument* self = new (ELeave) CS60ClientServLabDocument( aApp );
    CleanupStack::PushL( self );
    self->ConstructL();
    CleanupStack::Pop();

    return self;
    }
    
// ----------------------------------------------------
// CS60ClientServLabDocument::CreateAppUiL()
// constructs CS60ClientServLabAppUi
// ----------------------------------------------------
//
CEikAppUi* CS60ClientServLabDocument::CreateAppUiL()
    {
    return new (ELeave) CS60ClientServLabAppUi;
    }

// End of File  
