// Copyright (c) 2006 Nokia Corporation.

// INCLUDE FILES
#include <eikstart.h>
#include "S60ClientServerLabApplication.h"


LOCAL_C CApaApplication* NewApplication()
	{
	return new CS60ClientServerLabApp;
	}

GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication( NewApplication );
	}

