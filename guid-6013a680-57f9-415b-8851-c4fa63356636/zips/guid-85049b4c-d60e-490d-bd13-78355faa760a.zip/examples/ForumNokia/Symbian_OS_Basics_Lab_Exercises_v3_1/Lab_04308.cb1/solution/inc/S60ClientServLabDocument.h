// Copyright (c) 2006 Nokia Corporation.

#ifndef S60CLIENTSERVLABDOCUMENT_H
#define S60CLIENTSERVLABDOCUMENT_H

// INCLUDES
#include <akndoc.h>
   
// CONSTANTS

// FORWARD DECLARATIONS
class  CEikAppUi;

// CLASS DECLARATION

/**
*  CS60ClientServLabDocument application class.
*/
class CS60ClientServLabDocument : public CAknDocument
    {
    public: // Constructors and destructor
        /**
        * Two-phased constructor.
        */
        static CS60ClientServLabDocument* NewL(CEikApplication& aApp);

        /**
        * Destructor.
        */
        virtual ~CS60ClientServLabDocument();

    public: // New functions

    protected:  // New functions

    protected:  // Functions from base classes

    private:

        /**
        * EPOC default constructor.
        */
        CS60ClientServLabDocument(CEikApplication& aApp);
        void ConstructL();

    private:

        /**
        * From CEikDocument, create CS60ClientServLabAppUi "App UI" object.
        */
        CEikAppUi* CreateAppUiL();
    };

#endif

// End of File

