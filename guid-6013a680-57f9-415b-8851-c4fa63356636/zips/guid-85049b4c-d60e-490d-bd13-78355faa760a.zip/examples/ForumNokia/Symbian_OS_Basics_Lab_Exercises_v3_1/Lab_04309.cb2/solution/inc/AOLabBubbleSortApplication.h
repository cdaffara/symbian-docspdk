// Copyright (c) 2006 Nokia Corporation.

#ifndef __AOLABBUBBLESORTAPPLICATION_H__
#define __AOLABBUBBLESORTAPPLICATION_H__

#include <aknapp.h>

// CAOLabBubbleSortApplication application class.
// Provides factory to create concrete document object.
// An instance of CAOLabBubbleSortApplication is the application part of the
// AVKON application framework for the AOLabBubbleSort example application.
class CAOLabBubbleSortApplication : public CAknApplication
    {
    public: // Functions from base classes

        TUid AppDllUid() const;

    protected: // Functions from base classes

        CApaDocument* CreateDocumentL();
    };

#endif // __AOLABBUBBLESORTAPPLICATION_H__

// End of File
