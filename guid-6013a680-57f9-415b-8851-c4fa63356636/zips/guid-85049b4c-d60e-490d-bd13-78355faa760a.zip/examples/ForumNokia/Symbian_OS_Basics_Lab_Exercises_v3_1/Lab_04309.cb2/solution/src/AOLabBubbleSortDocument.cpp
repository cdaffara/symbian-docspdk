// Copyright (c) 2006 Nokia Corporation.

#include "AOLabBubbleSortAppUi.h"
#include "AOLabBubbleSortDocument.h"

// Constructs a document object for this application
CAOLabBubbleSortDocument* CAOLabBubbleSortDocument::NewL(CEikApplication& aApp)
    {
    CAOLabBubbleSortDocument* self = NewLC(aApp);
    CleanupStack::Pop( self );
    return self;
    }

// Constructs a document object for this application and places it on the cleanupstack.
CAOLabBubbleSortDocument* CAOLabBubbleSortDocument::NewLC(CEikApplication& aApp)
    {
    CAOLabBubbleSortDocument* self = new (ELeave) CAOLabBubbleSortDocument(aApp);
    CleanupStack::PushL( self );
    self->ConstructL();
    return self;
    }


// Symbian 2nd phase constructor
void CAOLabBubbleSortDocument::ConstructL()
    {
    // No implementation required
    }


// C++  constructor
CAOLabBubbleSortDocument::CAOLabBubbleSortDocument( CEikApplication& aApp )
    : CAknDocument( aApp )
    {
    // No implementation required
    }


// Destructor
CAOLabBubbleSortDocument::~CAOLabBubbleSortDocument()
    {
    // No implementation required
    }


// Called by the application framework to create the application UI object
CEikAppUi* CAOLabBubbleSortDocument::CreateAppUiL()
    {
    return (new (ELeave) CAOLabBubbleSortAppUi);
    }

// End of File
