// Copyright (c) 2006 Nokia Corporation.

#ifndef __AOLABBUBBLESORTAPPUI_h__
#define __AOLABBUBBLESORTAPPUI_h__

#include <aknappui.h>

class CAOLabBubbleSortContainer;

// Application UI class.
class CAOLabBubbleSortAppUi : public CAknAppUi
    {
    public: // Constructors and destructor

        void ConstructL();
        CAOLabBubbleSortAppUi();
        virtual ~CAOLabBubbleSortAppUi();

    private:  // Functions from base classes

        // From CEikAppUi
        void HandleCommandL( TInt aCommand );

        // From MEikStatusPaneObserver
		void HandleStatusPaneSizeChange();
		
		void DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane);
        
    private: // Data

        CAOLabBubbleSortContainer* iAppContainer;    
    };

#endif // __AOLABBUBBLESORTAPPUI_h__

// End of File
