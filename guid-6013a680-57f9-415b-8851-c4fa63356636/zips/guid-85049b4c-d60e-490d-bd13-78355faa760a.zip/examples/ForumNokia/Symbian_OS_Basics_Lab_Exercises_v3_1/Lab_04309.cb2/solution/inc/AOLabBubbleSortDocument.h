// Copyright (c) 2006 Nokia Corporation.

#ifndef __AOLABBUBBLESORTDOCUMENT_h__
#define __AOLABBUBBLESORTDOCUMENT_h__

#include <akndoc.h>

class CAOLabBubbleSortAppUi;
class CEikApplication;

// CAOLabBubbleSortDocument application class.
// An instance of class CAOLabBubbleSortDocument is the Document part of the
// AVKON application framework for the AOLabBubbleSort example application.
class CAOLabBubbleSortDocument : public CAknDocument
    {
    public: // Constructors and destructor

        static CAOLabBubbleSortDocument* NewL(CEikApplication& aApp);
        static CAOLabBubbleSortDocument* NewLC(CEikApplication& aApp);
        virtual ~CAOLabBubbleSortDocument();

    public: // Functions from base classes

        CEikAppUi* CreateAppUiL();

    private: // Constructors

        void ConstructL();
        CAOLabBubbleSortDocument( CEikApplication& aApp );
    };

#endif // __AOLABBUBBLESORTDOCUMENT_h__

// End of File
