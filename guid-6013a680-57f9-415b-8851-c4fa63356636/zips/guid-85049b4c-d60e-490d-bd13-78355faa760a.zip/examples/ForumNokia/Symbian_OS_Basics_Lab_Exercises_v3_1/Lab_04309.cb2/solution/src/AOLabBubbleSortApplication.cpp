// Copyright (c) 2006 Nokia Corporation.

#include "AOLabBubbleSortDocument.h"
#include "AOLabBubbleSortApplication.h"

// UID for the application
const TUid KUidAOLabBubbleSortApp = { 0x0515DFCE };


// Creates CApaDocument object
CApaDocument* CAOLabBubbleSortApplication::CreateDocumentL()
    {
    return CAOLabBubbleSortDocument::NewL(*this);
    }


// Returns application UID
TUid CAOLabBubbleSortApplication::AppDllUid() const
    {
    return KUidAOLabBubbleSortApp;
    }

// End of File
