// Copyright (c) 2006 Nokia Corporation.

#ifndef __BUBBLESORTNOTIFY_H__
#define __BUBBLESORTNOTIFY_H__

class MBubbleSortNotify 
{
public:
/*!
  @function ReadChunk

  @discussion Notifies caller of read of all data.  
              Data is contain in aData (or NULL if error)
              Caller is responsible for deleting aData
  */
    virtual void SortComplete(TInt aError) = 0;
};

#endif // __BUBBLESORTNOTIFY_H__

// End of file

