// Copyright (c) 2006 Nokia Corporation.

#include <eikstart.h>
#include "AOLabBubbleSortApplication.h"


// Called by the application framework to create the application object
LOCAL_C CApaApplication* NewApplication()
	{
	return new CAOLabBubbleSortApplication;
	}


// Entry point function
GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication( NewApplication );
	}

// End of file