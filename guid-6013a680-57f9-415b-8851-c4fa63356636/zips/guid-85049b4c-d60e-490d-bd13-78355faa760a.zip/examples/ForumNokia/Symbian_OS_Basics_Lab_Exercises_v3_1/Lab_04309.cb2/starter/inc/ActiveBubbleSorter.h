// Copyright (c) 2006 Nokia Corporation.

#ifndef __ACTIVEBUBBLESORTER_H__
#define __ACTIVEBUBBLESORTER_H__

#include <e32base.h>
#include <f32file.h>

class CActiveBubbleSorter : public CActive
	{
	public: // Construction/destruction

    	static CActiveBubbleSorter* NewL();
    	~CActiveBubbleSorter();

	protected: // from CActive

		// from CActive
    	void DoCancel();
    	void RunL();
		TInt RunError(TInt aError);
		
	private: // Construction
    
    	CActiveBubbleSorter();
    	void ConstructL();

	public: // Public functions
	
    	void StartL();
    	
	private: // Internal functions
	
		void ReadNumbersFromFileL();
		void WriteNumbersToFileL();

	private: // data
	};

#endif // __ACTIVEBUBBLESORTER_H__

// End of file
