/*
 * Copyright � 2009 Nokia Corporation.
 */

#ifndef BLUETOOTHPMPEXAMPLEDOCUMENT_H
#define BLUETOOTHPMPEXAMPLEDOCUMENT_H

// INCLUDES
#include <akndoc.h>

// CONSTANTS

// FORWARD DECLARATIONS
class  CEikAppUi;

// CLASS DECLARATION

/**
*  CBluetoothPMPExampleDocument application class.
*/
class CBluetoothPMPExampleDocument : public CAknDocument
    {
    public: // Constructors and destructor
        /**
        * Two-phased constructor.
        */
        static CBluetoothPMPExampleDocument* NewL(CEikApplication& aApp);

        /**
        * Destructor.
        */
        virtual ~CBluetoothPMPExampleDocument();

    public: // New functions

    protected:  // New functions

    protected:  // Functions from base classes

    private:

        /**
        * EPOC default constructor.
        */
        CBluetoothPMPExampleDocument(CEikApplication& aApp);

        void ConstructL();

    private:

        /**
        * From CEikDocument, create CBluetoothPMPExampleAppUi "App UI" object.
        */
        CEikAppUi* CreateAppUiL();
    };

#endif

// End of File

