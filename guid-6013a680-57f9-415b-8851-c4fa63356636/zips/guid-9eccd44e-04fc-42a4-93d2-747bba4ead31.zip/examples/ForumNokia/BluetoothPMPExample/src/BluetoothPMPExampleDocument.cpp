/*
 * Copyright � 2009 Nokia Corporation.
 */

// INCLUDE FILES
#include "BluetoothPMPExampleDocument.h"
#include "BluetoothPMPExampleAppUi.h"


CBluetoothPMPExampleDocument* CBluetoothPMPExampleDocument::NewL(
        CEikApplication& aApp)     // CBluetoothPMPExampleApp reference
    {
    CBluetoothPMPExampleDocument* self = 
        new (ELeave) CBluetoothPMPExampleDocument( aApp );
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);

    return self;
    }


// ----------------------------------------------------------------------------
// CBluetoothPMPExampleDocument::CBluetoothPMPExampleDocument(CEikApplication& 
//   aApp)
//
// constructor
// ----------------------------------------------------------------------------
CBluetoothPMPExampleDocument::CBluetoothPMPExampleDocument(
    CEikApplication& aApp): CAknDocument(aApp)    
    {
    }


// ----------------------------------------------------------------------------
// CBluetoothPMPExampleDocument::~CBluetoothPMPExampleDocument()
//
// destructor
// ----------------------------------------------------------------------------
CBluetoothPMPExampleDocument::~CBluetoothPMPExampleDocument()
    {
    }


// ----------------------------------------------------------------------------
// CBluetoothPMPExampleDocument::ConstructL()
//
// Standard EPOC 2nd phase constructor
// ----------------------------------------------------------------------------
void CBluetoothPMPExampleDocument::ConstructL()
    {
    }
    

// ----------------------------------------------------------------------------
// CBluetoothPMPExampleDocument::CreateAppUiL()
//
// constructs CBluetoothPMPExampleAppUi
// ----------------------------------------------------------------------------
CEikAppUi* CBluetoothPMPExampleDocument::CreateAppUiL()
    {
    return new (ELeave) CBluetoothPMPExampleAppUi;
    }

// End of File  
