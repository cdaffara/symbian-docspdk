// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// Transient server example - client interface
//

#ifndef __T_CLIENT_H__
#define __T_CLIENT_H__

#include <e32std.h>

class RMySession : public RSessionBase
	{
public:
	IMPORT_C TInt Connect();
	IMPORT_C TInt Send(const TDesC& aMessage);
	IMPORT_C void Receive(TRequestStatus& aStatus,TDes& aMessage);
	IMPORT_C void CancelReceive();
	};

#endif
