/*
 * Copyright � 2008 Nokia Corporation.
 */

#ifndef CONTACTSMODELAPP_H
#define CONTACTSMODELAPP_H

// INCLUDES
#include <aknapp.h>

// CONSTANTS
// UID of the application
const TUid KUidContactsModel = { 0xE9A18D08 };

// CLASS DECLARATION

/**
* CContactsModelApp application class.
* Provides factory to create concrete document object.
*
*/
class CContactsModelApp : public CAknApplication
    {

    public: // Functions from base classes
    private:

        /**
        * From CApaApplication, creates CContactsModelDocument document object.
        * @return A pointer to the created document object.
        */
        CApaDocument* CreateDocumentL();

        /**
        * From CApaApplication, returns application's UID (KUidContactsModel).
        * @return The value of KUidContactsModel.
        */
        TUid AppDllUid() const;
    };

#endif

// End of File

