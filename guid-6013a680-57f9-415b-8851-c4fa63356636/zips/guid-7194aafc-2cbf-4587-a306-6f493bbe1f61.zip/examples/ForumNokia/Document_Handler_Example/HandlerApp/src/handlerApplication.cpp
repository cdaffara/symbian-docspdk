/* ====================================================================
 * File: handlerApplication.cpp
 * Created: 09/27/05
 * Author: 
 * Copyright (c): , All rights reserved
 * ==================================================================== */

#include "handlerDocument.h"
#include "handlerApplication.h"

// UID for the application, this should correspond to the uid defined in the mmp file
const TUid KUidhandlerApp = {0x0F084DF7};

CApaDocument* CHandlerApplication::CreateDocumentL()
    {  
    // Create an handler document, and return a pointer to it
    CApaDocument* document = CHandlerDocument::NewL(*this);
    return document;
    }

TUid CHandlerApplication::AppDllUid() const
    {
    // Return the UID for the handler application
    return KUidhandlerApp;
    }

