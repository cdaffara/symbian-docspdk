/* ====================================================================
 * File: Common.h
 * Created: 15/06/06
 * Author:
 *

 *   Contains common constants for the example.
 *
 * Copyright (c): , All rights reserved
 * ==================================================================== */

#ifndef ___COMMON_H__
#define ___COMMON_H__

//How many characters to read from the file
const TInt KTextLengthToRead = 20;

#endif //___COMMON_H__

