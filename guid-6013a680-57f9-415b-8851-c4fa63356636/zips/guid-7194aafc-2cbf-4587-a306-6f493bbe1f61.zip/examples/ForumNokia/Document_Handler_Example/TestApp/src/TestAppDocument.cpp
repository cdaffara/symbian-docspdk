/* ====================================================================
 * File: TestAppDocument.cpp
 * Created: 28/06/06 by Forum Nokia
 * Author: 
 * Copyright (c): , All rights reserved
 * ==================================================================== */

#include "TestAppAppUi.h"
#include "TestAppDocument.h"

CTestAppDocument* CTestAppDocument::NewL(CEikApplication& aApp)
    {
    CTestAppDocument* self = NewLC(aApp);
    CleanupStack::Pop(self);
    return self;
    }

CTestAppDocument* CTestAppDocument::NewLC(CEikApplication& aApp)
    {
    CTestAppDocument* self = new (ELeave) CTestAppDocument(aApp);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }

void CTestAppDocument::ConstructL()
    {
	// no implementation required
    }    

CTestAppDocument::CTestAppDocument(CEikApplication& aApp) : CAknDocument(aApp) 
    {
	// no implementation required
    }

CTestAppDocument::~CTestAppDocument()
    {
	// no implementation required
    }

CEikAppUi* CTestAppDocument::CreateAppUiL()
    {
    // Create the application user interface, and return a pointer to it,
    // the framework takes ownership of this object
    return new (ELeave) CTestAppAppUi;
    }

