/* ====================================================================
 * File: TestApp.cpp
 * Created: 28/06/06 by Forum Nokia
 * Author: 
 * Copyright (c): , All rights reserved
 * ==================================================================== */

#include "TestAppApplication.h"

//#ifdef __SERIES60_3X__
    #include <eikstart.h>
//#endif

// ---------------------------------------------------------------------------
// NewApplication()
//
// Return new instance of the DBMS application.
// ---------------------------------------------------------------------------
EXPORT_C CApaApplication* NewApplication()
    {
    return (static_cast<CApaApplication*>(new CTestAppApplication));
    }
/*
#ifndef __SERIES60_3X__
// ---------------------------------------------------------
// E32Dll(TDllReason) 
// Entry point function for EPOC Apps
// Returns: KErrNone: No error
// ---------------------------------------------------------
//
GLDEF_C TInt E32Dll( TDllReason )
{
    return KErrNone; 
}
#else
*/
// ---------------------------------------------------------
// E32Main()
// Entry point function for new (>= 9.0) EPOC Apps (exe)
// Returns: System Wide error codes or KErrNone if all goes well
// ---------------------------------------------------------
//
GLDEF_C TInt E32Main()
{
	return EikStart::RunApplication( NewApplication );
}
//#endif


