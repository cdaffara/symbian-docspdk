/* ====================================================================
 * File: TestAppApplication.cpp
 * Created: 28/06/06 by Forum Nokia
 * Author:
 * Copyright (c): , All rights reserved
 * ==================================================================== */

#ifdef __SERIES60_3X__
    #include <eikstart.h>
#endif

#include "TestAppDocument.h"
#include "TestAppApplication.h" 

// UID for the application, this should correspond to the uid defined in the mmp file
static const TUid KUidTestAppApp = {0x0F084DF8};

CApaDocument* CTestAppApplication::CreateDocumentL()
    {
    // Create an TestApp document, and return a pointer to it
    CApaDocument* document = CTestAppDocument::NewL(*this);
    return document;
    }

TUid CTestAppApplication::AppDllUid() const
    {
    // Return the UID for the TestApp application
    return KUidTestAppApp;
    }


// End of File

