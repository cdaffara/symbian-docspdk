/*
 * Copyright � 2008 Nokia Corporation.
 */



// INCLUDE FILES
#include <eikstart.h>

#include "LocalizationApplication.h"

EXPORT_C CApaApplication* NewApplication()
    {
    return static_cast<CApaApplication*>( new CLocalizationApplication );
    }

GLDEF_C TInt E32Main()
    {
    return EikStart::RunApplication( NewApplication );
    }
    
