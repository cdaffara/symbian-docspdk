/*
* ============================================================================
*  Name     : CTaskManagerDocument from TaskManagerDocument.h
*  Part of  : TaskManager
*  Created  : 08/31/2005 by Forum Nokia
*  Description:
*     Declares document for application.
*  Version  : 1.01
*  Copyright: Nokia Corporation
* ============================================================================
*/

#ifndef __TASKMANAGER_DOCUMENT_H__
#define __TASKMANAGER_DOCUMENT_H__

// INCLUDE FILES
#include <akndoc.h>

// FORWARD DECLARATIONS
class CTaskManagerAppUi;
class CEikApplication;

// CLASS DECLARATION

/**
*  CTaskManagerDocument document class.
*/
class CTaskManagerDocument : public CAknDocument
{
public: // Constructors and destructor

	/**
	* Two-phased constructor.
	*/
	static CTaskManagerDocument* NewL(CEikApplication& aApp);

	/**
	* Destructor.
	*/
	~CTaskManagerDocument();

private:

	/**
	* Symbian OS default constructor.
	*/
    CTaskManagerDocument(CEikApplication& aApp);
    void ConstructL();

    /**
    * From CEikDocument, create CTaskManagerDocument "App UI" object.
    */
    CEikAppUi* CreateAppUiL();

};


#endif // __TASKMANAGER_DOCUMENT_H__

// End of file
