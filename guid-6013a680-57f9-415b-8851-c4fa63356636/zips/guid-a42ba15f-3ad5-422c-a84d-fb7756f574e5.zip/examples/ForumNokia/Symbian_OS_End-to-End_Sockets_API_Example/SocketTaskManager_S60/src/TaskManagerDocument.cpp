/*
* ============================================================================
*  Name     : CTaskManagerDocument from TaskManagerDocument.cpp
*  Part of  : TaskManager
*  Created  : 15/03/2006 by Forum Nokia
*  Version  : 1.2
*  Copyright: Nokia Corporation
* ============================================================================
*/

// INCLUDE FILES
#include "TaskManagerAppUi.h"
#include "TaskManagerDocument.h"

// ================= MEMBER FUNCTIONS =======================

// constructor
CTaskManagerDocument::CTaskManagerDocument(CEikApplication& aApp) : CAknDocument(aApp) 
{
	// no implementation required
}

// destructor
CTaskManagerDocument::~CTaskManagerDocument()
{
	// no implementation required
}

// ----------------------------------------------------
// CTaskManagerDocument::NewL()
// Two-phased constructor.
// ----------------------------------------------------
// 
CTaskManagerDocument *CTaskManagerDocument::NewL(CEikApplication &aApp)
{
    CTaskManagerDocument *self = new(ELeave) CTaskManagerDocument(aApp);
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
}

// ----------------------------------------------------
// CTaskManagerDocument::ConstructL()
// Symbian OS default constructor can leave.
// ----------------------------------------------------
// 
void CTaskManagerDocument::ConstructL()
{
	// no implementation required
}    


// ----------------------------------------------------
// CTaskManagerDocument::CreateAppUiL()
// constructs CTaskManagerAppUi
// ----------------------------------------------------
//
CEikAppUi *CTaskManagerDocument::CreateAppUiL()
{
    // Create the application user interface, and return a pointer to it,
    // the framework takes ownership of this object
    CEikAppUi *appUi = new(ELeave) CTaskManagerAppUi;
    return appUi;
}

// End of file
