/*
* ==============================================================================
*  Name        : csasyncapplication.cpp
*  Part of     : CSAsync
*  Interface   :
*  Description :
*  Version     :
*
*  Copyright (c) 2004-2006 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/


// INCLUDE FILES
#include "CSAsyncDocument.h"
#include "CSAsyncApplication.h"

// ========================= MEMBER FUNCTIONS ==================================

// -----------------------------------------------------------------------------
// CCSAsyncApplication::CreateDocumentL()
// Creates a CSAsync document, and return a pointer to it
// -----------------------------------------------------------------------------
//
CApaDocument* CCSAsyncApplication::CreateDocumentL()
    {
    return ( static_cast<CApaDocument*>( CCSAsyncDocument::NewL( *this ) ) );
    }

// ----------------------------------------------------------------------------
// TUid CCSAsyncApplication::AppDllUid()
// Returns the UID for the CSAsync application
// ----------------------------------------------------------------------------
//
TUid CCSAsyncApplication::AppDllUid() const
    {
    return KUidCSAsyncApp;
    }


// End of File
