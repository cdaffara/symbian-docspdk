/*
* ==============================================================================
*  Name        : asynctimeobserver.h
*  Part of     : CSAsync
*  Interface   :
*  Description :
*  Version     :
*
*  Copyright (c) 2004-2006 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/


#ifndef __ASYNCTIMEOBSERVER_H__
#define __ASYNCTIMEOBSERVER_H__

// CLASS DECLARATION
/**
* MAsyncTimeObserver
*  Mixin class.
*  Observer which handles updates from the server example application.
*/
class MAsyncTimeObserver
    {
    public:
        /**
        * HandleTimeUpdate.
        * Handle updates from the server.
        */
        virtual void HandleTimeUpdate() = 0;
    };

#endif // __ASYNCTIMEOBSERVER_H__

// End of File