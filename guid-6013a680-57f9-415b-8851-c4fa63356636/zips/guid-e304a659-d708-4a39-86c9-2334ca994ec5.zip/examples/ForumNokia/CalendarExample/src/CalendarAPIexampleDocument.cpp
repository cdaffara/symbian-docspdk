/*
 * Copyright � 2008 Nokia Corporation.
 */

// INCLUDE FILES

#include "CalendarAPIexampleDocument.h"
#include "CalendarAPIexampleAppUi.h"
#include <calentry.h>

// ================= MEMBER FUNCTIONS =======================

// constructor
CCalendarAPIexampleDocument::CCalendarAPIexampleDocument(CEikApplication& aApp)
: CAknDocument(aApp)
    {
    }

// destructor
CCalendarAPIexampleDocument::~CCalendarAPIexampleDocument()
    {
    }

// Symbian OS default constructor can leave.
void CCalendarAPIexampleDocument::ConstructL()
    {
    }

// Two-phased constructor.
CCalendarAPIexampleDocument* CCalendarAPIexampleDocument::NewL(
        CEikApplication& aApp) 
    {
    CCalendarAPIexampleDocument* self = new (ELeave) CCalendarAPIexampleDocument( aApp );
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);

    return self;
    }

// ----------------------------------------------------
// CCalendarAPIexampleDocument::CreateAppUiL()
// constructs CCalendarAPIexampleAppUi
// ----------------------------------------------------
//
CEikAppUi* CCalendarAPIexampleDocument::CreateAppUiL()
    {
    return new (ELeave) CCalendarAPIexampleAppUi;
    }

// End of File
