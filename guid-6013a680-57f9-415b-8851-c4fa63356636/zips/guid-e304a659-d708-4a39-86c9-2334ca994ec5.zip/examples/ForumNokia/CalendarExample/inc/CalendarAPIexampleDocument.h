/*
 * Copyright � 2008 Nokia Corporation.
 */


#ifndef CALENDARAPIEXAMPLEDOCUMENT_H
#define CALENDARAPIEXAMPLEDOCUMENT_H

// INCLUDE FILES
#include <akndoc.h>   //CAknDocument

// FORWARD DECLARATIONS
class  CEikAppUi;
class  CCalendarAPIexampleEngine;
    
// CLASS DECLARATION

/*!
*  CCalendarAPIexampleDocument application class.
*/
class CCalendarAPIexampleDocument : public CAknDocument
    {
public: // Constructors and destructor
   /*!
    * Two-phased constructor.
    */
    static CCalendarAPIexampleDocument* NewL(CEikApplication& aApp);

   /*!
    * Destructor.
    */
    virtual ~CCalendarAPIexampleDocument();

public: // New functions


private:

   /*!
    * Symbian OS default constructor.
    */
    CCalendarAPIexampleDocument(CEikApplication& aApp);
    void ConstructL();

   /*!
    * From CEikDocument, create CCalendarAPIexampleAppUi "App UI" object.
    */
    CEikAppUi* CreateAppUiL();

private: // data members   

    };



#endif

// End of File

