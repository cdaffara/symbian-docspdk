/*
* ==============================================================================
*  Name        : example.h
*  Part of     : OpenCStringUtilitiesExeEx
*  Interface   : 
*  Description : 
*  Version     : 
*
*  Copyright (c) 2005-2007 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation.
* ==============================================================================
*/

#include 	<stdlib.h>
#include 	<stdio.h>
#include	<e32base.h>

// Header for the stringutils library
#include 	"stringutils.h"

#define		SIZE 50

#define 	GETCHAR()	printf("press any key to continue....\n"),getchar();



//Function prototypes
void testTbuf16();
void testTbuf8();
void testTbufC8();
void testTbufC16();
void testHbufC16();
void testHbufC8();

void testWchar();
void testChar();