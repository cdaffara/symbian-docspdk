// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// CPP file demonstrating Extension DLL pattern
// This file contains the implementation of the extension functions which
// have been declared in the numberstore.h file.
// These file will be built into extensiondll.dll and thus in order to use
// this function a client must link to extensiondll.lib
// NOTE this file is unchanged from the version used previously, but it must be 
// rebuilt to align with the rearranged ordinals in originaldll_v2
//

#include "NumberStore_v2.h"

//Implementation of the added function

EXPORT_C TInt CNumberStore::AddNumbers () const
	{
	return (iNumber1+iNumber2);
	}

EXPORT_C TInt CNumberStore::MultiplyNumbers() const
	{
	return DoMultiplyNumbers();
	}
