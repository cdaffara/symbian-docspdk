// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

//	This header file contains the class definitions for:
//	CResData
#include "CommonFile.hrh"

class CResData : public CBase
	{
public:
	~CResData();
	static	CResData* NewLC(TResourceReader& aReader);
	void	ShowData(const TInt aStructNum = 0);
private:
    void	ConstructL(TResourceReader& aReader);
private:
	TInt        	iWrd;		// STRUCT member type: WORD,
	TInt			iFlags;     // WORD
	TInt			iLng;		// LONG,
	TInt         	iByt;		// BYTE,
	TReal			iDbl;		// DOUBLE,
	TBufC<TEXTMAX>  iTxt;		// LTEXT (maximum length specified),
	HBufC*        	iLtxt;	  	// LTEXT
	};


				



