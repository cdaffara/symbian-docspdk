/*
* ==============================================================================
*  Name        : cssyncapplication.cpp
*  Part of     : CSSync
*  Interface   :
*  Description :
*  Version     :
*
*  Copyright (c) 2006 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/


// INCLUDE FILES
#include "CSSyncDocument.h"
#include "CSSyncApplication.h"

// ========================= MEMBER FUNCTIONS ==================================

// -----------------------------------------------------------------------------
// CCSSyncApplication::CreateDocumentL()
// Creates a CSSync document, and return a pointer to it
// -----------------------------------------------------------------------------
//
CApaDocument* CCSSyncApplication::CreateDocumentL()
    {
    return( static_cast<CApaDocument*>( CCSSyncDocument::NewL( *this ) ) );
    }

// -----------------------------------------------------------------------------
// CCSSyncApplication::AppDllUid()
// Return the UID for the CSSync application
// -----------------------------------------------------------------------------
//
TUid CCSSyncApplication::AppDllUid() const
    {
    return KUidCSSyncApp;
    }


// End of File
