// Copyright (c) 2006-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef __CONTROLFRAMEWORKAPPLICATION_H
#define __CONTROLFRAMEWORKAPPLICATION_H

#include <eikapp.h>

//Application class
class CControlFrameworkApplication : public CEikApplication
	{
public:
	static CApaApplication* NewApplication();
	~CControlFrameworkApplication();
	
private:
	CControlFrameworkApplication();
	
	// from CApaApplication
	TUid AppDllUid() const;
	CApaDocument* CreateDocumentL();
	};


#endif // __CONTROLFRAMEWORKAPPLICATION_H

