// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef CMSGQACTIVE_H_
#define CMSGQACTIVE_H_

#include <e32base.h>
#include "e32msgqueue.h"  //used for NotifyDataAvailable API

class CMsgQActive : public CActive
{
public:
	static CMsgQActive* NewL(TInt aPriority = EPriorityStandard);
	CMsgQActive(TInt aPriority = EPriorityStandard);
	virtual ~CMsgQActive();
	virtual void DoCancel(); 
	virtual void RunL(); 
	void StartRecieving(); 
	void ConstructL(); 
private:
	TBuf<100> imsgQData; //Buffer to store recieved data.
	RMsgQueue<TBuf<100> > iInverterOutQ;
	CConsoleBase* iConsole; //console to display words recieved from the inverter via the message queue.
};

#endif /*CMSGQACTIVE_H_*/
