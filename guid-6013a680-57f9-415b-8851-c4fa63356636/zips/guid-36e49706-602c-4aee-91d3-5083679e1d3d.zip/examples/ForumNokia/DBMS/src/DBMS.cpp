/*
 * Copyright � 2008 Nokia Corporation.
 */

#include "DBMSApplication.h"
#include <eikstart.h>

// ---------------------------------------------------------------------------
// NewApplication()
//
// Return new instance of the DBMS application.
// ---------------------------------------------------------------------------
EXPORT_C CApaApplication* NewApplication()
    {
    return (static_cast<CApaApplication*>(new CDBMSApplication));
    }

// ---------------------------------------------------------
// E32Main()
// Entry point function for new (>= 9.0) EPOC Apps (exe)
// Returns: Sistem Wide error codes or KErrNone if all goes well
// ---------------------------------------------------------
//
GLDEF_C TInt E32Main()
{
	return EikStart::RunApplication( NewApplication );
}


