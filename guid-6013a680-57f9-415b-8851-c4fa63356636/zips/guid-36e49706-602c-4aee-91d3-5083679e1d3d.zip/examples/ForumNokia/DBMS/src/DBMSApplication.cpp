/*
 * Copyright � 2008 Nokia Corporation.
 */

#include "DBMSDocument.h"
#include "DBMSApplication.h"

// Uid for the application, this should match the one in the mmp file
const TUid KUidDBMSApp = {0xE01F5466};
 

// ---------------------------------------------------------------------------
// CDBMSAppUi::CreateDocumentL()
//
// Create the document for the DBMS application.
// ---------------------------------------------------------------------------
CApaDocument* CDBMSApplication::CreateDocumentL()
    {
    return (static_cast<CApaDocument*>(CDBMSDocument::NewL(*this)));
    }

// ---------------------------------------------------------------------------
// CDBMSAppUi::AppDllUid()
//
// Return the UID of this DBMS application
// ---------------------------------------------------------------------------
TUid CDBMSApplication::AppDllUid() const
    {
    return KUidDBMSApp;
    }

