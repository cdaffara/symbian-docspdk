EComCalculator\client\Readme.txt

EComCalculator is simple Avkon GUI application, which calculates sum
and product of two numbers. It uses custom ECOM interface to do the
calculation (see ..\interface)

The essential part regarding ECOM is implementation of method
    CEComCalculatorAppUi::DoEComCalculationL(const TDesC8& aOperationName,
        TReal aA, TReal aB, TReal& aResult)
It is in .\src\EComCalculatorAppui.cpp

For build instructions, refer to ..\Release_notes.txt