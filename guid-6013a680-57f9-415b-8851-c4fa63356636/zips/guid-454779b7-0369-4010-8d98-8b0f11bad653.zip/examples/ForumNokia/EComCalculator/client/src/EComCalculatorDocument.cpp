/*
 * ============================================================================
 *  Name     : CEComCalculatorDocument from EComCalculatorDocument.cpp
 *  Part of  : EComCalculator
 *  Created  : 17/11/2003 by Forum Nokia
 *  Version  : 1.0
 *  Copyright: Nokia Corporation
 * ============================================================================
 */

#include "EComCalculatorAppUi.h"
#include "EComCalculatorDocument.h"

// Create instance of document.
CEComCalculatorDocument* CEComCalculatorDocument::NewL(CEikApplication& aApp)
    {
    CEComCalculatorDocument* self = new (ELeave) CEComCalculatorDocument(aApp);
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }

// Perform second phase construction
void CEComCalculatorDocument::ConstructL()
    {
    // No implementation required
    }

// Constructor
CEComCalculatorDocument::CEComCalculatorDocument(CEikApplication& aApp)
: CAknDocument(aApp)
    {
    // No implementation required
    }

// Destructor
CEComCalculatorDocument::~CEComCalculatorDocument()
    {
    // No implementation required
    }

// Create the AppUi.
CEikAppUi* CEComCalculatorDocument::CreateAppUiL()
    {
    return (static_cast<CEikAppUi*>(new(ELeave)CEComCalculatorAppUi));
    }

