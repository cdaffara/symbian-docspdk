/*
 * ============================================================================
 *  Name     : EComCalculator from EComCalculator.h
 *  Part of  : EComCalculator
 *  Created  : 29/05/2006 by Forum Nokia
 *  Version  : 2.0
 *  Copyright: Nokia Corporation
 * ============================================================================
 */

#include "EComCalculatorApplication.h"
//#ifdef __SERIES60_3X__
#include <eikstart.h>
//#endif


// Return new instance of the EComCalculator application.
EXPORT_C CApaApplication* NewApplication()
    {
    return (static_cast<CApaApplication*>(new CEComCalculatorApplication));
    }

/*
#ifndef __SERIES60_3X__
// ---------------------------------------------------------
// E32Dll(TDllReason)
// Entry point function for EPOC Apps
// Returns: KErrNone: No error
// ---------------------------------------------------------
//
GLDEF_C TInt E32Dll( TDllReason )
{
    return KErrNone;
}
#else
*/
// ---------------------------------------------------------
// E32Main()
// Entry point function for new (>= 9.0) EPOC Apps (exe)
// Returns: Sistem Wide error codes or KErrNone if all goes well
// ---------------------------------------------------------
//
GLDEF_C TInt E32Main()
{
    return EikStart::RunApplication( NewApplication );
}
//#endif

