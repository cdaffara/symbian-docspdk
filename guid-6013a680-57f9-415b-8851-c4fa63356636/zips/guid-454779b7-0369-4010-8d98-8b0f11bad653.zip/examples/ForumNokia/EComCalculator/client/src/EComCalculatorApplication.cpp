/*
 * ============================================================================
 *  Name     : CEComCalculatorApplication from EComCalculatorApplication.cpp
 *  Part of  : EComCalculator
 *  Created  : 29/05/2006 by Forum Nokia
 *  Version  : 2.0
 *  Copyright: Nokia Corporation
 * ============================================================================
 */

#include "EComCalculatorDocument.h"
#include "EComCalculatorApplication.h"

// Uid for the application. This must match the one in the EComCalculator.mmp.
#ifdef __SERIES60_3X__
    const TUid KUidEComCalculatorApp = {0xE01F5464};
#else
    const TUid KUidEComCalculatorApp = {0x101F5464};
#endif


// Create the document for the EComCalculator application.
CApaDocument* CEComCalculatorApplication::CreateDocumentL()
    {
    return (static_cast<CApaDocument*>(CEComCalculatorDocument::NewL(*this)));
    }

// Return the UID of the application
TUid CEComCalculatorApplication::AppDllUid() const
    {
    return KUidEComCalculatorApp;
    }

