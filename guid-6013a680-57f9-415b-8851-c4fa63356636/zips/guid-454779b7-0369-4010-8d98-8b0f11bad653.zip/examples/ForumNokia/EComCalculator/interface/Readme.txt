EComCalculator\interface\Readme.txt

This folder contains ECOM interface definition for EComCalculator example. 
Clients will use the interface to get instance of concrete implementation, 
and the plugin implementations implement the pure virtual Calculate(a,b) method.

