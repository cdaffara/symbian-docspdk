EComCalculator\plugin\Readme.txt

EComImplementation is dll plugin component, which provides two implementations
for custom ECOM interface (see interface definition in ..\interface).


BUILDING

For build instructions, refer to ..\Release_notes.txt

      
INSTALLATION TO DEVICE      

refer to ..\Release_notes.txt

FILES:

The classes
    CImplementationClassMultiply in EComImplementationMultiply.h
    CImplementationClassPlus     in EComImplementationPlus.h
implement the interface's Calculate(..) method. They are the concrete
implementations, which ECOM framework returns to clients.

Resource file 101F5465.rss describes contents of the plugin dll. Essentially,
it defines IMPLEMENTATION_INFO::default_data for individual impelementations. 
The field is used by ECOM framework's default resolver to find requested 
implementation for a client. 

Proxy.cpp defines where within the dll the implementations reside. The ECOM 
framework uses chart of TImplementationProxy items to map implementation Ids
to locations of specific implementations instantiation methods (NewL). Each 
implementation Id within TImplementationProxy must match one of the defined in
the 101F5465.RSS resource file.

Note: The name of compiled resource file must be same as UID of the DLL  
      in S60 2nd edition. In 3rd edition it must much the DLLs name.
      This ensures the ECOM plugin framework can match the dll and resource file.
