// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef __PROCESSCLIENT_H__
#define __PROCESSCLIENT_H__

#include <e32base.h>
#include <e32std.h>

/**
	Client interface for process server
*/
class RProcessClient : public RSessionBase
	{
public:
	IMPORT_C TInt Connect();
	IMPORT_C TInt OpenDriver();
	
	IMPORT_C void Send(const TDesC8& aBuf, TRequestStatus& aStatus);
	IMPORT_C void SendCancel();
	
	IMPORT_C TInt UnloadDeviceDriver();
	IMPORT_C TInt LoadDeviceDriver();
	};

#endif
