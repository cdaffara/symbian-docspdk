// Copyright (c) 2005-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#if !defined(__BIOEXAMPLEPARSER_H__)
#define __BIOEXAMPLEPARSER_H__


#include <bsp.h>
#include <msventry.h>


class CBIOExampleParser : public CBaseScriptParser2
{
public:
	IMPORT_C static CBIOExampleParser* NewL(CRegisteredParserDll& aRegisteredParserDll, CMsvEntry& aEntry, RFs& aFs);
	~CBIOExampleParser();
	void ParseL(TRequestStatus& aStatus, const TDesC& aSms);
	void ProcessL(TRequestStatus& aStatus);

private:
    void DoCancel();
    void RunL();

    CBIOExampleParser(CRegisteredParserDll& aRegisteredParserDll, CMsvEntry& aEntry, RFs& aFs);
    void ConstructL();
};

#endif /*__BIOEXAMPLEPARSER_H__*/
