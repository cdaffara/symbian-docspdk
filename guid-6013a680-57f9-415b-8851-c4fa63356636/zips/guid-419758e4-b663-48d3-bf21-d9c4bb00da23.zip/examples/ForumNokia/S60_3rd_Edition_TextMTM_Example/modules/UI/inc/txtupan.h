// TXTUPAN.H
//
// � 2004 Nokia Corporation.  All rights reserved.
//

#ifndef __TXTMTMPAN_H__
#define __TXTMTMPAN_H__

//
//	TTxtuMtmUdPanic: MTM panics
//
enum TTxtuMtmUdPanic
	{
	ETextMtmUiSelectionIsNotOneMessage,
	ETextMtmUiOnlyWorksWithMessageEntries,
	ETextMtmUiEmptySelection,
	ETextMtmUiWrongMtm,
	ETextMtmUiWrongEntryType,
	ETextMtmUiInvalidNullPointer,
    ETextMtmUiOperationActive,
    ETextMtmUiNotLocalEntry
	};
	
_LIT(KTEXTMTMUIPanic,"TEXT MTMUI");

GLREF_C void Panic(TTxtuMtmUdPanic aPanic);

#endif  //__TXTMTMPAN_H__
