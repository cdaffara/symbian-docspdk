// TXTUDLL.CPP
//
// � 2004 Nokia Corporation.  All rights reserved.
//

#include <E32STD.H>
#include "txtu.h"           // CBaseMtmUi
#include "txtupan.h"        // panic codes

// Global function declarations

GLDEF_C void Panic(TTxtuMtmUdPanic aPanic)
// Panic function
	{
	User::Panic(KTEXTMTMUIPanic, aPanic);
	}

EXPORT_C CBaseMtmUi* NewMtmUiL(CBaseMtm& aMtm, CRegisteredMtmDll& aRegisteredDll)
// Factory function
	{
	return CTextMtmUi::NewL(aMtm, aRegisteredDll);
	}

