

#include "TxtViewerService.h"

#include <E32STD.H>    // KNullUid
#include <ApgCli.h>
#include <eikenv.h>
#include <eikappui.h>
#include <AknServerApp.h>
#include <barsread2.h>


#define KTxtViewerServiceUid    	0x10FFFFFF
#define KUid						0xA000017F
#define KMsgServiceView				0x00000001
#define KMsgServiceEdit				0x00000002

// ---------------------------------------------------------
// RTxtViewerService::OpenL
// ---------------------------------------------------------
//
void RTxtViewerService::OpenL( const TEditorParameters aParams )
	{
	
	TIpcArgs args;
	args.Set(0, aParams.iEntry);
	args.Set(1, aParams.iOpenedForEditing);

	
	TInt err = 
		SendReceive(
			RApaAppServiceBase::KServiceCmdBase, 
			args );
	User::LeaveIfError(err);
	}

// ---------------------------------------------------------
// RTxtViewerService::ServiceUid
// ---------------------------------------------------------
//
TUid RTxtViewerService::ServiceUid() const
	{
	return TUid::Uid( KTxtViewerServiceUid );
	}

////////////////////////////////////////////////////////////////////


