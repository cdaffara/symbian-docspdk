// TXTCPAN.H
//
// � 2004 Nokia Corporation.  All rights reserved.
//

#if !defined(__TXTCPAN_H__)
#define __TXTCPAN_H__

#if !defined(__E32BASE_H__)
#include <e32base.h>
#endif

//
//	TTxtcPanic: MTM panics
//
enum TTxtcPanic
	{
	ETxtcNoBodyText,
	ETxtcBadMtmTypeUid,
	ETxtcNoCMsvEntrySet,
	ETxtcEntryTypeNotSupported,
	ETxtcCommandNotSupported,
	ETxtcInvalidServiceId,
    ETxtcOperationIsActive
	};

_LIT(KTxtCPanic,"TXTC");

GLREF_C void gPanic(TTxtcPanic aPanic);

#endif
