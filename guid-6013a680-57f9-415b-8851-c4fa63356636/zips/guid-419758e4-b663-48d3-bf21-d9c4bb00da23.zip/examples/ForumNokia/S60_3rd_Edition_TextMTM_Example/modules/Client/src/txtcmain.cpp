// TXTCMAIN.CPP
//
// � 2004 Nokia Corporation.  All rights reserved.
//

#include <e32std.h>
#include "txtcpan.h"



GLDEF_C void gPanic(TTxtcPanic aPanic)
	{
	User::Panic(KTxtCPanic,aPanic);
	}
