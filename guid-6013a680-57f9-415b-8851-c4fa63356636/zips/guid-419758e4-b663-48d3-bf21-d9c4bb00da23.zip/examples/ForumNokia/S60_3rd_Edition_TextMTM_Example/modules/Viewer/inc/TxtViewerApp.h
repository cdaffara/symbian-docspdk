

#ifndef TXTVIEWERAPP_H
#define TXTVIEWERAPP_H

//  INCLUDES
#include <eikapp.h>                 // CEikApplication

// CONSTANTS
const TUid KUidTxtViewer ={0xA00058BD};


// CLASS DECLARATION

/**
*  CTxtViewerApplication class
*  Needed by the EIKON framework
*/
class CTxtViewerApplication : public CEikApplication
    {
    private:  
    void NewAppServerL( CApaAppServer*& aAppServer );
    CApaDocument* CreateDocumentL();    // abstract in CEikApplication
    TUid AppDllUid() const;             // abstract in CApaApplication
    };

#endif      //  TXTVIEWERAPP_H
// End of File
