

// INCLUDE FILES
#include "Txtviewerdoc.h"        // Documentpart of the Symbian OS app
#include "Txtviewerapp.h"        // Applicationpart of the Symbian OS app
#include "TxtViewerAppServer.h"

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// CTxtViewerApplication::AppDllUid
// Returns the application's uid to the UIKON framework
// 
// ---------------------------------------------------------
TUid CTxtViewerApplication::AppDllUid() const
    {
    return KUidTxtViewer;
    }

// ---------------------------------------------------------
// CTxtViewerApplication::CreateDocumentL
// Part of the UIKON framework's application construction. Creates Doc-part.
// 
// ---------------------------------------------------------
CApaDocument* CTxtViewerApplication::CreateDocumentL()
    {
    return CTxtViewerDocument::NewL(*this);
    }

// ---------------------------------------------------------
// CTxtViewerApplication::NewAppServerL
// 
// ---------------------------------------------------------
void CTxtViewerApplication::NewAppServerL( CApaAppServer*& aAppServer )
    {
    aAppServer = new (ELeave) CTxtViewerAppServer;
    }
// ================= OTHER EXPORTED FUNCTIONS ==============

#include <eikstart.h>
LOCAL_C CApaApplication* NewApplication()
    {
	return new CTxtViewerApplication;
    }
    
GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication( NewApplication );
    }

