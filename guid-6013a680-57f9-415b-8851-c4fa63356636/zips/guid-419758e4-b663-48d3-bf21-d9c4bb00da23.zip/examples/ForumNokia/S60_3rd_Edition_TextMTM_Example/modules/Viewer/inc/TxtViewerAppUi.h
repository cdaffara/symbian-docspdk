/*
* ============================================================================
*  Name     : CTxtViewerAppUi 
*  
*
*  Description:
*     
*  Version:
*
*  Copyright (C) 2002 - 2005 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing,  adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
*
* ============================================================================
*/

#ifndef MSGSMSVIEWERAPPUI_H
#define MSGSMSVIEWERAPPUI_H

// INCLUDES
#include <eikapp.h>		// CEikApplication
#include <eikdoc.h>		// CEikDocument
#include <e32std.h>		// Standard epoc32 includes
#include <coeccntx.h>	// Graphics contexts
#include <aknappui.h>	// CAknAppUi
#include <mtmuibas.h>	// UI Base MTM

class CTxtViewerAppView;
class CTxtViewerDocument;

//////////////////////////////////////////////////////////////////////////////
//
// -----> CActiveConsole (definition)
//
// An abstract class which provides the facility to issue key requests. 
//
//////////////////////////////////////////////////////////////////////////////
class CWaiter : public CActive
	{
public:
	  // Construction
	CWaiter();
	void ConstructL();

	  // Destruction
	~CWaiter();

	 void Request();
	
	  // Cancel request.
	  // Defined as pure virtual by CActive;
	  // implementation provided by this class.
	void DoCancel();

	  // Service completed request.
	  // Defined as pure virtual by CActive;
	  // implementation provided by this class,
	void RunL();

	  
protected:

	};

// CLASS DECLARATION

/**
*  CTxtViewerAppUi
*  Inherited from CMsgEditorAppUi
*/
class CTxtViewerAppUi : public CAknAppUi
                         
    {
    public:  // Constructors and destructor

		CTxtViewerDocument* Document() const;
        
        
        

        /**
        * C++ default constructor.
        */
        CTxtViewerAppUi();

        /**
        * Destructor.
        */
        virtual ~CTxtViewerAppUi();

    protected: // New functions
	private:  
	    void SendL();   
	    void SaveToDraftsL();       
    protected: // Functions from base classes
        
            
        
        /**
        * From CCoeAppUi 
        * @param aKeyEvent look from CCoeAppUi
        * @param aType look from CCoeAppUi
        * @return TKeyResponse look from CCoeAppUi
        */
        virtual TKeyResponse HandleKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);

        /**
        * From CEikAppUi 
        * @param aCommand look from CEikAppUi
        */
        virtual void HandleCommandL(TInt aCommand);

        /**
        * From MEikMenuObserver 
        * @param aMenuId look from MEikMenuObserver
        * @param aMenuPane look from MEikMenuObserver
        */
        virtual void DynInitMenuPaneL(TInt aMenuId, CEikMenuPane* aMenuPane);
        
        /**
         * From CEikAppUi 
         */        
        void HandleStatusPaneSizeChange();
                
    protected:

        /**
        * By default Symbian OS constructor is private.
        */
        virtual void ConstructL();

    protected:     // Data
	private:
	
		CTxtViewerAppView* iAppView;
	    CMsvOperation* iOp;
	    TRequestStatus iStatus;
		CMsvEntrySelection* iSelection;
	    TMsvId iServiceId;
        };
#endif // MSGSMSVIEWERAPPUI_H
//  End of File
