// Copyright (c) 2005-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//


#ifndef __CANSWERINCOMINGCALL_H__
#define __CANSWERINCOMINGCALL_H__

#include <e32base.h>
#include <e32cons.h>
#include <e32def.h>
#include <etel3rdparty.h>

#include "CISVAPIAsync.h"

#include "CMainMenu.h"

/**
Answer the incoming call.
*/
class CAnswerIncomingCall : public CISVAPIAsync
	{
	// Methods
public:
	static CAnswerIncomingCall* NewL(MExecAsync* aController);
	~CAnswerIncomingCall();

	void DoStartRequestL();

private:
	CAnswerIncomingCall(MExecAsync* aController);
	void ConstructL();

	void RunL();
	void DoCancel();

	// Data
public:
	/**
	Stores details of the incoming call.
	*/
	CTelephony::TCallId iCallId;
	/**
	Stores the status of the incoming call.
	*/
	CTelephony::TCallStatusV1 iCallStatusV1;

private:
	/**
	Packages iCallStatusV1.
	*/
	CTelephony::TCallStatusV1Pckg iCallStatusV1Pckg;
	};

#endif // __CANSWERINCOMINGCALL_H__
