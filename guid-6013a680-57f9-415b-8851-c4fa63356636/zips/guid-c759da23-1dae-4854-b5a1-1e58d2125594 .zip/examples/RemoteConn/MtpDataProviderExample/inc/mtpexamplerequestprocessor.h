// Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//


#ifndef MTPEXAMPLEREQUESTPROCESSOR_H_
#define MTPEXAMPLEREQUESTPROCESSOR_H_

class MMTPConnection;
class TMTPTypeRequest;
class CMTPDataProviderPlugin;
class MMTPDataProviderFramework;
class MMTPExampleDpRequestProcessor;

/** 
 Defines file data provider request processor factory.
 */
class MTPExampleDpProcessor
    {
public:
    static MMTPExampleDpRequestProcessor* CreateL(MMTPDataProviderFramework& aFramework,const TMTPTypeRequest& aRequest, MMTPConnection& aConnection);   
    };
    

#endif /* MTPEXAMPLEREQUESTPROCESSOR_H_ */
