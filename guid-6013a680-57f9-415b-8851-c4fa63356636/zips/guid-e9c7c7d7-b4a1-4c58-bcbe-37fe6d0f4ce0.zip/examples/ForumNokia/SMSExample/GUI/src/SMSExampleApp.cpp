/*
 * Copyright � 2008 Nokia Corporation.
 */

// INCLUDE FILES
#include <avkon.hrh>
#include <avkon.rsg>
#include <SmsExample.rsg>
#include "SMSExampleApp.h"
#include "SMSExampleDocument.h"

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// CSMSExampleApp::AppDllUid()
// Returns application UID
// ---------------------------------------------------------
//
TUid CSMSExampleApp::AppDllUid() const
    {
    return KUidSMSExample;
    }


// ---------------------------------------------------------
// CSMSExampleApp::CreateDocumentL()
// Creates CSMSExampleDocument object
// ---------------------------------------------------------
//
CApaDocument* CSMSExampleApp::CreateDocumentL()
    {
    return CSMSExampleDocument::NewL( *this );
    }

// End of File
