/** @file passwd.c
 * Contained the implementation to test auth library
 */
/*
* ==============================================================================
*  Name        : passwd.c
*  Part of     : Open C/Example code
*  Description : This is used to test auth library.
*  Version     : 1.0
*
*  Copyright (c) 2007 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/

// system include
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
//#include <staticlibinit_gcce.h>
#include "wsddll.h"

/**
* Debug message
* @param aMessagePtr pointer to the message
* @param aErrNo
*/

/**
* application entry point
*/

int main(void)
{
	char str[20];

	printf ("DLL global int value : %d\n",GetDllInt());
	GetDllString(str);
	printf ("DLL global String value : %s\n",str);

	SetDllInt(1008);
	SetDllString("HelloWorld");

	printf ("DLL global int value : %d\n",GetDllInt());
	GetDllString(str);
	printf ("DLL global String value : %s\n",str);

    printf("Press any key to exit.\n");
    getchar();
    return 0;
}

//End of file
