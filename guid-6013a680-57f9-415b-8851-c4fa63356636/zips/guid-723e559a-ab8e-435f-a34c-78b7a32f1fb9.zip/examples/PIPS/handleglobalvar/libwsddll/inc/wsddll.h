/** @file auth.h
 * Contained the declaration of all methods, exported by this library.
 */ 

/*
* ==============================================================================
*  Name        : auth.h
*  Part of     : Open C/Example code
*  Description : This is used to handle user authentication.
*
*  Version     : 1.0
*
*  Copyright (c) 2007 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/

#ifndef AUTH_H
#define AUTH_H

// system include
#include <_ansi.h>
#include <e32def.h>

#ifdef __cplusplus
extern "C" {
#endif


IMPORT_C TInt GetDllInt();
IMPORT_C void GetDllString(char *str);
IMPORT_C void SetDllInt(const int i);
IMPORT_C void SetDllString(char *str);

#ifdef __cplusplus
}
#endif

#endif // AUTH_H

// End of file
