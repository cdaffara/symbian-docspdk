/*
 * Copyright � 2008 Nokia Corporation.
 */

// INCLUDES
#include <eikstart.h>
#include "ThreadAOApplication.h"

LOCAL_C CApaApplication* NewApplication()
    {
    return new CThreadAOApplication;
    }
    
GLDEF_C TInt E32Main()
    {
    return EikStart::RunApplication( NewApplication );
    }
