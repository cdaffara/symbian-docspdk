/*
 * Copyright � 2008 Nokia Corporation.
 */


// INCLUDES
#include "ThreadAODocument.h"
#include "ThreadAOApplication.h"

// UID for the application; this should correspond to the uid defined in the
// mmp file
const TUid KUidThreadApp = {0xE01FF1CB};

CApaDocument* CThreadAOApplication::CreateDocumentL()
    {  
    // Create an ThreadAO document, and return a pointer to it
	return (static_cast<CApaDocument*>(CThreadAODocument::NewL(*this))); 
    }

TUid CThreadAOApplication::AppDllUid() const
    {
    // Return the UID for the Thread application
    return KUidThreadApp;
    }

