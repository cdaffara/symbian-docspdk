/*
 * Copyright � 2008 Nokia Corporation.
 */


#ifndef __THREAD_APPLICATION_H__
#define __THREAD_APPLICATION_H__

// INCLUDES
#include <aknapp.h>


/*! 
* CThreadAOApplication
*  
*  discussion An instance of CThreadAOApplication is the application part of the AVKON
*  application framework for the ThreadAO example application
 */
class CThreadAOApplication : public CAknApplication
    {
public:  // from CAknApplication

/*! 
* AppDllUid()
*  
* discussion Return the application DLL UID value
* result the UID of this Application/Dll
*/
    TUid AppDllUid() const;

protected: // from CAknApplication

/*! 
* CreateDocumentL
*  
* discussion Create a CApaDocument object and return a pointer to it
* result a pointer to the created document
*/
    CApaDocument* CreateDocumentL();
    };

#endif // __THREAD_APPLICATION_H__
