// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#include <e32base.h>
#include <e32std.h>

/**
	Server shut down delay class
*/
class CDelayServerShutDown : public CActive
    {
public:
    // Construct/destruct
    static CDelayServerShutDown* NewL();
    ~CDelayServerShutDown(); 
    // Set time delay
    void SetDelay(TTimeIntervalMicroSeconds32 aDelay);   
private:
    // Construct/destruct
    CDelayServerShutDown();
    void ConstructL();

    // From CActive
    void RunL();
    void DoCancel();   
private:
	/** For shutdown, after a delay */
    RTimer iShutDownTimer;     
    };

 //EOF
