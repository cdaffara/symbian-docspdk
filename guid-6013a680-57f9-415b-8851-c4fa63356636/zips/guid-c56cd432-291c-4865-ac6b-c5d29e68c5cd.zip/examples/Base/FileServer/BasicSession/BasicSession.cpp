// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// This example opens the file server session, and prints 
// "Hello File Server!" to the console.
// Used as the basis of all F32 examples
// Note that no data is written.
//

#include "CommonFramework.h"
#include <f32file.h>
	

static RFs fsSession;

// start of real example

static void doExampleL()
    {
	// open file server session
	User::LeaveIfError(fsSession.Connect()); // connect session
	// say hello
	_LIT(KGreeting,"Hello File Server!\n");
	console->Printf(KGreeting);
	fsSession.Close(); // close file server session
	}
